'use strict'
const AWS = require('aws-sdk');
AWS.config.update({ region: "us-east-1" });
const wordsDictionary = require('./wordsDictionary.js'); // this could be dictionary library or other source with more words 

exports.handler = async (
    event,
) => {
    const documentClient = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });

    try {
        const number = "1 (214) 211-2879"; // hard coded phone number passed by Connect
        const { phoneNumber } = event ? JSON.parse(event.body) : number;

        const processedNumber = formatNumber(phoneNumber);
        const vanityList = await generateVanityNumbers(processedNumber, documentClient);

        const finalVanityList = vanityList.slice(-3); // taking the last three (or fewer) elements of the array to return to Connect
        console.log(finalVanityList, 'finalVanityList')
        const response = {
            statusCode: 201,
            body: JSON.stringify(finalVanityList)
        }
        return response;
    } catch (err) {
        const response = {
            statusCode: 403,
            body: "Error"
        }
        return response;
    }
};

// Format Phone Number
const formatNumber = (number) => {
    // Trim and remove country code
    return number.trim().replace(/\+/g, '').replace(/-/g, '').replace(/\(/g, '').replace(/\)/g, '').replace(/\s/g, '').slice(-10);
};

// Checks if vanity number list already exists. If so, returns it. If not, generates a vanity list.
const generateVanityNumbers = async (number, dynamoClient) => {
    let vanityList = await checkNumber(number, dynamoClient);

    if (vanityList.length > 0) {
        //if the vanityList is already in the database, return it
        return vanityList;
    }

    vanityList = [];

    const firstSix = number.slice(0, 6);
    const lastFour = number.slice(6).split('');

    const dialPad = new Map([
        ['0', '0'],
        ['1', '1'],
        ['2', 'ABC'],
        ['3', 'DEF'],
        ['4', 'GHI'],
        ['5', 'JKL'],
        ['6', 'MNO'],
        ['7', 'PQRS'],
        ['8', 'TUV'],
        ['9', 'WXYZ'],
    ]);

    const firstStr = dialPad.get(lastFour[0]).split('');
    const secondStr = dialPad.get(lastFour[1]).split('');
    const thirdStr = dialPad.get(lastFour[2]).split('');
    const fourthStr = dialPad.get(lastFour[3]).split('');

    for (let i = 0; i < firstStr.length; i++) {
        if (vanityList.length >= 15) {
            // list already contains 15 items
            break;
        }

        for (let j = 0; j < secondStr.length; j++) {
            if (vanityList.length >= 15) {
                break;
            }

            for (let k = 0; k < thirdStr.length; k++) {
                if (vanityList.length >= 15) {
                    break;
                }

                for (let m = 0; m < fourthStr.length; m++) {
                    if (vanityList.length >= 15) {
                        break;
                    }

                    const phoneWord = firstStr[i] + secondStr[j] + thirdStr[k] + fourthStr[m];
                    const vanityNumber = firstSix + phoneWord;

                    if (vanityList.length < 5) {
                        //if the vanityList is with length smaller than 5 items
                        vanityList.push(vanityNumber);
                    } else if (wordsDictionary.includes(phoneWord.toUpperCase())) {
                       // ?console.log(phoneWord.toUpperCase(), 'ttoUpper');
                      // ? console.log(wordsDictionary.includes(phoneWord.toUpperCase()), 'includdes?');
                        // will add up to the first five matches found in the word dictionary
                        vanityList.push(vanityNumber);
                    }
                }
            }
        }
    }
    console.log('Generated vanity numbers! Saving to db: ' + vanityList);
    vanityList = vanityList.slice(-5); //only consider the last 5 (or fewer) elements added
    console.log('Generated vanity numbers! Saving to db: ' + vanityList);
    await save(number, vanityList, dynamoClient);

    return vanityList;
};


// Checks if the number already exists in the DynamoDB
const checkNumber = async (number, dynamoClient) => {
    const params = {
        TableName: 'VanityNumbersTable',
        Key: {
            phoneNumber: number,
        },
    };

    let responseBody="";
    let statusCode = 0; 

    try {
        const data = await dynamoClient.get(params).promise();
        responseBody = JSON.stringify(data.Item['vanityNumbers']);
        console.log(data);
        statusCode = 200;
        const response = {
            statusCode: statusCode,
            body: responseBody
        }
        return response;
    } catch (err) {
        responseBody = 'Unable to get user data'
        statusCode = 403;
        return []
    }
};

// Saves an item to the Dynamo table
const save = async (number, vanityList, dynamoClient) => {
    let responseBody="";
    let statusCode = 0; 

    const params = {
        TableName: 'VanityNumbersTable',
        Item: {
            phoneNumber: number,
            vanityNumbers: vanityList,
        },
    };
    try {
        const data = await dynamoClient.put(params).promise();
        responseBody = JSON.stringify(data.Item);
        console.log(data);
        statusCode = 201;
    } catch (err) {
        if (err) {
            responseBody = 'Unable to get user data'
            statusCode = 403;
        }
    }

    const response = {
        statusCode: statusCode,
        body: responseBody
    }
    return response;

};